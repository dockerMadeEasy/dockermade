angular.module('dockerMadeEasy.docker').component('porImageRegistry', {
  templateUrl: 'app/docker/components/imageRegistry/porImageRegistry.html',
  controller: 'porImageRegistryController',
  bindings: {
    'image': '=',
    'registry': '=',
    'autoComplete': '<'
  }
});
