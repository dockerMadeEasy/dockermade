function StatusViewModel(data) {
  this.Authentication = data.Authentication;
  this.EndpointManagement = data.EndpointManagement;
  this.Analytics = data.Analytics;
  this.Version = data.Version;
}
