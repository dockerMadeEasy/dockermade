angular.module('dockerMadeEasy.app', [])
.config(['$stateRegistryProvider', function ($stateRegistryProvider) {
  'use strict';

  var root = {
    name: 'root',
    abstract: true,
    resolve: {
      requiresLogin: ['StateManager', function (StateManager) {
        var applicationState = StateManager.getState();
        return applicationState.application.authentication;
      }]
    },
    views: {
      'sidebar@': {
        templateUrl: 'app/dockerMadeEasy/views/sidebar/sidebar.html',
        controller: 'SidebarController'
      }
    }
  };

  var dockerMadeEasy = {
    name: 'dockerMadeEasy',
    parent: 'root',
    abstract: true
  };

  var about = {
    name: 'dockerMadeEasy.about',
    url: '/about',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/about/about.html'
      }
    }
  };

  var account = {
    name: 'dockerMadeEasy.account',
    url: '/account',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/account/account.html',
        controller: 'AccountController'
      }
    }
  };

  var authentication = {
    name: 'dockerMadeEasy.auth',
    url: '/auth',
    params: {
      logout: false,
      error: ''
    },
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/auth/auth.html',
        controller: 'AuthenticationController'
      },
      'sidebar@': {}
    },
    data: {
      requiresLogin: false
    }
  };

  var init = {
    name: 'dockerMadeEasy.init',
    abstract: true,
    url: '/init',
    data: {
      requiresLogin: false
    },
    views: {
      'sidebar@': {}
    }
  };

  var initEndpoint = {
    name: 'dockerMadeEasy.init.endpoint',
    url: '/endpoint',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/init/endpoint/initEndpoint.html',
        controller: 'InitEndpointController'
      }
    }
  };

  var initAdmin = {
    name: 'dockerMadeEasy.init.admin',
    url: '/admin',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/init/admin/initAdmin.html',
        controller: 'InitAdminController'
      }
    }
  };

  var endpoints = {
    name: 'dockerMadeEasy.endpoints',
    url: '/endpoints',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/endpoints/endpoints.html',
        controller: 'EndpointsController'
      }
    }
  };

  var endpoint = {
    name: 'dockerMadeEasy.endpoints.endpoint',
    url: '/:id',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/endpoints/edit/endpoint.html',
        controller: 'EndpointController'
      }
    }
  };

  var endpointAccess = {
    name: 'dockerMadeEasy.endpoints.endpoint.access',
    url: '/access',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/endpoints/access/endpointAccess.html',
        controller: 'EndpointAccessController'
      }
    }
  };

  var registries = {
    name: 'dockerMadeEasy.registries',
    url: '/registries',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/registries/registries.html',
        controller: 'RegistriesController'
      }
    }
  };

  var registry = {
    name: 'dockerMadeEasy.registries.registry',
    url: '/:id',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/registries/edit/registry.html',
        controller: 'RegistryController'
      }
    }
  };

  var registryCreation  = {
    name: 'dockerMadeEasy.registries.new',
    url: '/new',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/registries/create/createregistry.html',
        controller: 'CreateRegistryController'
      }
    }
  };

  var registryAccess = {
    name: 'dockerMadeEasy.registries.registry.access',
    url: '/access',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/registries/access/registryAccess.html',
        controller: 'RegistryAccessController'
      }
    }
  };

  var settings = {
    name: 'dockerMadeEasy.settings',
    url: '/settings',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/settings/settings.html',
        controller: 'SettingsController'
      }
    }
  };

  var settingsAuthentication = {
    name: 'dockerMadeEasy.settings.authentication',
    url: '/auth',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/settings/authentication/settingsAuthentication.html',
        controller: 'SettingsAuthenticationController'
      }
    }
  };

  var users = {
    name: 'dockerMadeEasy.users',
    url: '/users',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/users/users.html',
        controller: 'UsersController'
      }
    }
  };

  var user = {
    name: 'dockerMadeEasy.users.user',
    url: '/:id',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/users/edit/user.html',
        controller: 'UserController'
      }
    }
  };

  var teams = {
    name: 'dockerMadeEasy.teams',
    url: '/teams',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/teams/teams.html',
        controller: 'TeamsController'
      }
    }
  };

  var team = {
    name: 'dockerMadeEasy.teams.team',
    url: '/:id',
    views: {
      'content@': {
        templateUrl: 'app/dockerMadeEasy/views/teams/edit/team.html',
        controller: 'TeamController'
      }
    }
  };

  $stateRegistryProvider.register(root);
  $stateRegistryProvider.register(dockerMadeEasy);
  $stateRegistryProvider.register(about);
  $stateRegistryProvider.register(account);
  $stateRegistryProvider.register(authentication);
  $stateRegistryProvider.register(init);
  $stateRegistryProvider.register(initEndpoint);
  $stateRegistryProvider.register(initAdmin);
  $stateRegistryProvider.register(endpoints);
  $stateRegistryProvider.register(endpoint);
  $stateRegistryProvider.register(endpointAccess);
  $stateRegistryProvider.register(registries);
  $stateRegistryProvider.register(registry);
  $stateRegistryProvider.register(registryAccess);
  $stateRegistryProvider.register(registryCreation);
  $stateRegistryProvider.register(settings);
  $stateRegistryProvider.register(settingsAuthentication);
  $stateRegistryProvider.register(users);
  $stateRegistryProvider.register(user);
  $stateRegistryProvider.register(teams);
  $stateRegistryProvider.register(team);
}]);
