angular.module('dockerMadeEasy.app').component('teamsDatatable', {
  templateUrl: 'app/dockerMadeEasy/components/datatables/teams-datatable/teamsDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    removeAction: '<'
  }
});
