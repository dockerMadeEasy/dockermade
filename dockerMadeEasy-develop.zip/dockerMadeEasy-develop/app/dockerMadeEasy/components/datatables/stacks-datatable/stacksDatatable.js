angular.module('dockerMadeEasy.app').component('stacksDatatable', {
  templateUrl: 'app/dockerMadeEasy/components/datatables/stacks-datatable/stacksDatatable.html',
  controller: 'StacksDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    showOwnershipColumn: '<',
    removeAction: '<',
    displayExternalStacks: '<'
  }
});
