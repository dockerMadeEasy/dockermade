angular.module('dockerMadeEasy.app').component('porAccessManagement', {
  templateUrl: 'app/dockerMadeEasy/components/accessManagement/porAccessManagement.html',
  controller: 'porAccessManagementController',
  bindings: {
    accessControlledEntity: '<',
    updateAccess: '&'
  }
});
