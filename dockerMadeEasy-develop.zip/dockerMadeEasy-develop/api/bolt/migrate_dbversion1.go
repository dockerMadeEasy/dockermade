package bolt

import (
	"github.com/boltdb/bolt"
	"github.com/dockerMadeEasy/dockerMadeEasy"
	"github.com/dockerMadeEasy/dockerMadeEasy/bolt/internal"
)

func (m *Migrator) updateResourceControlsToDBVersion2() error {
	legacyResourceControls, err := m.retrieveLegacyResourceControls()
	if err != nil {
		return err
	}

	for _, resourceControl := range legacyResourceControls {
		resourceControl.SubResourceIDs = []string{}
		resourceControl.TeamAccesses = []dockerMadeEasy.TeamResourceAccess{}

		owner, err := m.UserService.User(resourceControl.OwnerID)
		if err != nil {
			return err
		}

		if owner.Role == dockerMadeEasy.AdministratorRole {
			resourceControl.AdministratorsOnly = true
			resourceControl.UserAccesses = []dockerMadeEasy.UserResourceAccess{}
		} else {
			resourceControl.AdministratorsOnly = false
			userAccess := dockerMadeEasy.UserResourceAccess{
				UserID:      resourceControl.OwnerID,
				AccessLevel: dockerMadeEasy.ReadWriteAccessLevel,
			}
			resourceControl.UserAccesses = []dockerMadeEasy.UserResourceAccess{userAccess}
		}

		err = m.ResourceControlService.CreateResourceControl(&resourceControl)
		if err != nil {
			return err
		}
	}

	return nil
}

func (m *Migrator) updateEndpointsToDBVersion2() error {
	legacyEndpoints, err := m.EndpointService.Endpoints()
	if err != nil {
		return err
	}

	for _, endpoint := range legacyEndpoints {
		endpoint.AuthorizedTeams = []dockerMadeEasy.TeamID{}
		err = m.EndpointService.UpdateEndpoint(endpoint.ID, &endpoint)
		if err != nil {
			return err
		}
	}

	return nil
}

func (m *Migrator) retrieveLegacyResourceControls() ([]dockerMadeEasy.ResourceControl, error) {
	legacyResourceControls := make([]dockerMadeEasy.ResourceControl, 0)
	err := m.store.db.View(func(tx *bolt.Tx) error {
		bucket := tx.Bucket([]byte("containerResourceControl"))
		cursor := bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var resourceControl dockerMadeEasy.ResourceControl
			err := internal.UnmarshalResourceControl(v, &resourceControl)
			if err != nil {
				return err
			}
			resourceControl.Type = dockerMadeEasy.ContainerResourceControl
			legacyResourceControls = append(legacyResourceControls, resourceControl)
		}

		bucket = tx.Bucket([]byte("serviceResourceControl"))
		cursor = bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var resourceControl dockerMadeEasy.ResourceControl
			err := internal.UnmarshalResourceControl(v, &resourceControl)
			if err != nil {
				return err
			}
			resourceControl.Type = dockerMadeEasy.ServiceResourceControl
			legacyResourceControls = append(legacyResourceControls, resourceControl)
		}

		bucket = tx.Bucket([]byte("volumeResourceControl"))
		cursor = bucket.Cursor()
		for k, v := cursor.First(); k != nil; k, v = cursor.Next() {
			var resourceControl dockerMadeEasy.ResourceControl
			err := internal.UnmarshalResourceControl(v, &resourceControl)
			if err != nil {
				return err
			}
			resourceControl.Type = dockerMadeEasy.VolumeResourceControl
			legacyResourceControls = append(legacyResourceControls, resourceControl)
		}
		return nil
	})
	return legacyResourceControls, err
}

