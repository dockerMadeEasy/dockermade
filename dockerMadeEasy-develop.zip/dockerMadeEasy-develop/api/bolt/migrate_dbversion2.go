package bolt

import "github.com/dockerMadeEasy/dockerMadeEasy"

func (m *Migrator) updateSettingsToDBVersion3() error {
	legacySettings, err := m.SettingsService.Settings()
	if err != nil {
		return err
	}

	legacySettings.AuthenticationMethod = dockerMadeEasy.AuthenticationInternal
	legacySettings.LDAPSettings = dockerMadeEasy.LDAPSettings{
		TLSConfig: dockerMadeEasy.TLSConfiguration{},
		SearchSettings: []dockerMadeEasy.LDAPSearchSettings{
			dockerMadeEasy.LDAPSearchSettings{},
		},
	}

	err = m.SettingsService.StoreSettings(legacySettings)
	if err != nil {
		return err
	}

	return nil
}

