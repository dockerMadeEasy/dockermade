package http

import (
	"github.com/dockerMadeEasy/dockerMadeEasy"
	"github.com/dockerMadeEasy/dockerMadeEasy/http/handler"
	"github.com/dockerMadeEasy/dockerMadeEasy/http/handler/extensions"
	"github.com/dockerMadeEasy/dockerMadeEasy/http/proxy"
	"github.com/dockerMadeEasy/dockerMadeEasy/http/security"

	"net/http"
	"path/filepath"
)

// Server implements the dockerMadeEasy.Server interface
type Server struct {
	BindAddress            string
	AssetsPath             string
	AuthDisabled           bool
	EndpointManagement     bool
	Status                 *dockerMadeEasy.Status
	UserService            dockerMadeEasy.UserService
	TeamService            dockerMadeEasy.TeamService
	TeamMembershipService  dockerMadeEasy.TeamMembershipService
	EndpointService        dockerMadeEasy.EndpointService
	ResourceControlService dockerMadeEasy.ResourceControlService
	SettingsService        dockerMadeEasy.SettingsService
	CryptoService          dockerMadeEasy.CryptoService
	JWTService             dockerMadeEasy.JWTService
	FileService            dockerMadeEasy.FileService
	RegistryService        dockerMadeEasy.RegistryService
	DockerHubService       dockerMadeEasy.DockerHubService
	StackService           dockerMadeEasy.StackService
	StackManager           dockerMadeEasy.StackManager
	LDAPService            dockerMadeEasy.LDAPService
	GitService             dockerMadeEasy.GitService
	Handler                *handler.Handler
	SSL                    bool
	SSLCert                string
	SSLKey                 string
}

// Start starts the HTTP server
func (server *Server) Start() error {
	requestBouncer := security.NewRequestBouncer(server.JWTService, server.UserService, server.TeamMembershipService, server.AuthDisabled)
	proxyManager := proxy.NewManager(server.ResourceControlService, server.TeamMembershipService, server.SettingsService)

	var fileHandler = handler.NewFileHandler(filepath.Join(server.AssetsPath, "public"))
	var authHandler = handler.NewAuthHandler(requestBouncer, server.AuthDisabled)
	authHandler.UserService = server.UserService
	authHandler.CryptoService = server.CryptoService
	authHandler.JWTService = server.JWTService
	authHandler.LDAPService = server.LDAPService
	authHandler.SettingsService = server.SettingsService
	var userHandler = handler.NewUserHandler(requestBouncer)
	userHandler.UserService = server.UserService
	userHandler.TeamService = server.TeamService
	userHandler.TeamMembershipService = server.TeamMembershipService
	userHandler.CryptoService = server.CryptoService
	userHandler.ResourceControlService = server.ResourceControlService
	userHandler.SettingsService = server.SettingsService
	var teamHandler = handler.NewTeamHandler(requestBouncer)
	teamHandler.TeamService = server.TeamService
	teamHandler.TeamMembershipService = server.TeamMembershipService
	var teamMembershipHandler = handler.NewTeamMembershipHandler(requestBouncer)
	teamMembershipHandler.TeamMembershipService = server.TeamMembershipService
	var statusHandler = handler.NewStatusHandler(requestBouncer, server.Status)
	var settingsHandler = handler.NewSettingsHandler(requestBouncer)
	settingsHandler.SettingsService = server.SettingsService
	settingsHandler.LDAPService = server.LDAPService
	settingsHandler.FileService = server.FileService
	var templatesHandler = handler.NewTemplatesHandler(requestBouncer)
	templatesHandler.SettingsService = server.SettingsService
	var dockerHandler = handler.NewDockerHandler(requestBouncer)
	dockerHandler.EndpointService = server.EndpointService
	dockerHandler.TeamMembershipService = server.TeamMembershipService
	dockerHandler.ProxyManager = proxyManager
	var websocketHandler = handler.NewWebSocketHandler()
	websocketHandler.EndpointService = server.EndpointService
	var endpointHandler = handler.NewEndpointHandler(requestBouncer, server.EndpointManagement)
	endpointHandler.EndpointService = server.EndpointService
	endpointHandler.FileService = server.FileService
	endpointHandler.ProxyManager = proxyManager
	var registryHandler = handler.NewRegistryHandler(requestBouncer)
	registryHandler.RegistryService = server.RegistryService
	var dockerHubHandler = handler.NewDockerHubHandler(requestBouncer)
	dockerHubHandler.DockerHubService = server.DockerHubService
	var resourceHandler = handler.NewResourceHandler(requestBouncer)
	resourceHandler.ResourceControlService = server.ResourceControlService
	var uploadHandler = handler.NewUploadHandler(requestBouncer)
	uploadHandler.FileService = server.FileService
	var stackHandler = handler.NewStackHandler(requestBouncer)
	stackHandler.FileService = server.FileService
	stackHandler.StackService = server.StackService
	stackHandler.EndpointService = server.EndpointService
	stackHandler.ResourceControlService = server.ResourceControlService
	stackHandler.StackManager = server.StackManager
	stackHandler.GitService = server.GitService
	stackHandler.RegistryService = server.RegistryService
	stackHandler.DockerHubService = server.DockerHubService
	var extensionHandler = handler.NewExtensionHandler(requestBouncer)
	extensionHandler.EndpointService = server.EndpointService
	extensionHandler.ProxyManager = proxyManager
	var storidgeHandler = extensions.NewStoridgeHandler(requestBouncer)
	storidgeHandler.EndpointService = server.EndpointService
	storidgeHandler.TeamMembershipService = server.TeamMembershipService
	storidgeHandler.ProxyManager = proxyManager

	server.Handler = &handler.Handler{
		AuthHandler:           authHandler,
		UserHandler:           userHandler,
		TeamHandler:           teamHandler,
		TeamMembershipHandler: teamMembershipHandler,
		EndpointHandler:       endpointHandler,
		RegistryHandler:       registryHandler,
		DockerHubHandler:      dockerHubHandler,
		ResourceHandler:       resourceHandler,
		SettingsHandler:       settingsHandler,
		StatusHandler:         statusHandler,
		StackHandler:          stackHandler,
		TemplatesHandler:      templatesHandler,
		DockerHandler:         dockerHandler,
		WebSocketHandler:      websocketHandler,
		FileHandler:           fileHandler,
		UploadHandler:         uploadHandler,
		ExtensionHandler:      extensionHandler,
		StoridgeHandler:       storidgeHandler,
	}

	if server.SSL {
		return http.ListenAndServeTLS(server.BindAddress, server.SSLCert, server.SSLKey, server.Handler)
	}
	return http.ListenAndServe(server.BindAddress, server.Handler)
}
